let x=0;
function setup() {
  frameRate(30);
  createCanvas(500,500);
  push();
  background('#f2f0e6');
pop();
}

function draw() {
push();
push();
fill('#A8F0FF');
stroke(255)
ellipse(x,x,50);
x +=3;
pop();
push();
fill('#A8F0FF');
stroke(255)
ellipse(500,0,x);
let a=max(2,2);  
a *=2;
pop();
push();
let b= float(50.5)
fill('#A8F0FF');
stroke(255);
ellipse(200,x,b)
x--;
pop();
push();
fill('#FAEA7F');
stroke(255);
let mx= constrain(mouseX, 0, width);
print(mx);
ellipse(mouseX,mouseY,50,50);
pop();
push();
let d = dist(width, height, pmouseX, pmouseY);
print(d);
pop();
  


}
function setup() {
  createCanvas(500, 500);
}

function draw() {
push;
  background(255);
pop;
push;
fill('#F5DB20');
triangle(50,100,450,100,250,450);
pop;
push;
fill('#F5EC8B');
rect(50,100,400,50,20);
push;
fill(0);
ellipse(mouseX,mouseY,10);
//bug flying around pizza
pop;
push;
if (mouseIsPressed){
fill('#F51400');
ellipse(250,250,20);
} else {
  fill('#D68200');
ellipse(250,250,20);
}
if (keyIsPressed){
  fill('#F51400');
ellipse(150,200,20);
} else {
  fill('#D68200');
ellipse(350,200,20);
pop;
push;
for(let x=1; x<5; x++){
fill(0);
ellipse(50,50,5);
}
}
}
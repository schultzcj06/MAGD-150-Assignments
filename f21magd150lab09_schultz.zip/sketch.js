var song;


function preload(){
  //This establishes the sound file in the sketch.
  song = loadSound("446055__emilzendera98__wiping-a-mirror.wav");
}

function setup() {
  createCanvas(400, 400);
  //This adds reverb to the sound.
  reverb = new p5.Reverb();
  reverb.process(song, 3, 2);
  //This plays the sound.
  song.play();
}

function draw() {
  //This adds a black background.
  background(0);
  image("production ID_4440686.mp4");
}
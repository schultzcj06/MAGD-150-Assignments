let cam;
function setup() {
//Adding WEBGL allows for p5.js to use 3D modeling.
  createCanvas(400, 400,WEBGL);
  cam=createCamera;
}

function draw() {
  background(100);
  push();
  ambientLight(100);
  let locX = mouseX - width;
  let locY = mouseY - height/2;
//Adding this pointLight allows the user to affect how the light hits the torus.
  pointLight(255, 255, 255, locX, locY, 100);
  specularMaterial(120);
  shininess(10);
  torus(100,20);
  pop();
  push();
  orbitControl();
  directionalLight('#FF0000',250, 250, 250);
//Applying normalMaterial to the sphere gives it the rainbow look.
  normalMaterial();
  sphere(80);
  pop();
  push();
//Translating the box moves it out from underneath the sphere.
  translate(-140,-110)
  emissiveMaterial(15);
  box(40,80)
  pop();
}
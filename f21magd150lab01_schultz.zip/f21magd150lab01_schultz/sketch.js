function setup() {
  createCanvas(400,400);
}
function draw() {
  background(200);
  push();
    fill(0);
  rect(150,50,150,500);
  pop();
  push();
  ellipseMode(CORNERS);
  fill(255);
  ellipse(270,210,210,150);
  pop();
  push();
  fill(255);
  ellipse(200,100,50,50);
  push();
  fill(255);
  ellipse(260,100,50,50);
  pop();
  push();
  noFill;
  rect(160,340,130,200);
  pop();
  push();
  point(160,30);
  point (235,30);
  //guides for lines;
  pop();
  push();
  line(200,250,100,-300);
  line(200,250,288,-300); 
  pop();
  fill(0);
  rect(215,300,20,200);
}

